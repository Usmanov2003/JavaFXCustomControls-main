## JavaFX Custom Controls

This project will show different ways on how to create custom controls in JavaFX.
It will cover the following approaches:
* Restyle existing controls
* Combine existing controls
* Extending existing controls
* Create a Region based custom control
* Create a Control + Skin based custom control
* Create a Canvas based custom control
